"use strict";
const userName = prompt("Укажите ваше имя", "");

document.write(userName);
